<style>
#materialbox-overlay{
    background: rgba(0,0,0,.5);
}
    .galeria .card-image{
        height:200px;   
    }
    .cerrar_izquierda{
        float:right;
    }
    @media only screen and (max-width : 600px) {
        .cerrar_izquierda{
            text-align:right;
            float:none;
        }
    }
</style>
<?php 
/**
 * view.php define como se ve el bloque al usuario. La vista del mismo.
 */
defined('C5_EXECUTE') or die("Access Denied.");
$navigationTypeText = ($navigationType == 0) ? 'arrows' : 'pages';
$c = Page::getCurrentPage();

$cant = count($rows);
$pagina = intval(htmlspecialchars($this->controller->get("pg")));	
//$cantpg se refiere a la cantidad de items por página
$pgTotal = ceil($cant/$cantpg); //cantidad total de páginas
//Si está en modo de edición

if ($c->isEditMode()) { ?>
    <div class="ccm-edit-mode-disabled-item" style="width: <?php echo $width; ?>; height: <?php echo $height; ?>">
        <div style="padding: 40px 0px 40px 0px"><?php echo t('Clic izquierdo para editar la Galeria')?></div>
    </div>
<?php  } 
	//si se activa la vista pública

	else {
        ?><div class="row galeria" id="galeria"><?php
			if($pagina<$pgTotal) {
				$iInicial = $pagina*$cantpg;
				$iFinal = min(($iInicial+$cantpg), $cant);
				
				if($cant > 0) { 
					for($i=$iInicial; $i < $iFinal; $i++) { 
					
					$f = File::getByID($rows[$i]['fID']);
					
                 if(is_object($f)) { ?>
                <?php  ?>
				<div class="col l4 m6 s12">
                    <div class="card <?php echo $cantItemsPag ?>">
                        <div id="capa_item" class="card-image waves-effect waves-block waves-light" style="background:url(<?php echo $f->getURL(); ?>) no-repeat center center; background-size:cover" onclick="addData('<?php echo $f->getURL(); ?>','<?php echo $rows[$i]['titulo'];?>',$('#descripcion_item<?php echo $count-1 ?>').html());">
                        </div>
                        <div class="card-content">
                          <span class="card-title grey-text text-darken-4 right waves-effect waves-block" style="cursor:pointer" onclick="addData('<?php echo $f->getURL(); ?>','<?php echo $rows[$i]['titulo'];?>',$('#descripcion_item<?php echo $count-1 ?>').html());"><i class="material-icons right">search</i></span>
                          
                            <?php if($rows[$i]['titulo']) { ?>
                                <p><a onclick="addData('<?php echo $f->getURL(); ?>','<?php echo $rows[$i]['titulo'];?>',$('#descripcion_item<?php echo $count-1 ?>').html());" style="cursor:pointer"><?php echo $rows[$i]['titulo'];?></a></p>
                            <?php }else{ ?>
                                <p style="color:#FFF">.</p>
                            <?php } ?>
                            
                        </div>
                        <div class="card-reveal">
                          <span class="card-title grey-text text-darken-4"><?php echo $rows[$i]['titulo'];?><i class="material-icons right">close</i></span>
                          <p>Aqui tendria luego que estar una descripción</p>
                        </div>
                    </div>
                </div>
            <?php }
			}
			?>
					
</div>

<ul class="pagination" id="paginacion">
			<?php if($pagina>0) {?>
                <li class="waves-effect"><a href="?pg=<?php echo $pagina-1 ?>"><i class="material-icons">chevron_left</i></a></li>
            <?php }else{ ?>
                <li class="disabled"><a><i class="material-icons">chevron_left</i></a></li>
            <?php } ?>
    
            <?php for($i=0; $i < $pgTotal; $i++) {
                if( $i === $pagina ) {?>
                    <li class="active" style="background:#154354">
                <?php }else{ ?>
                    <li class="waves-effect">
                <?php } ?>
                <a href="?pg=<?php echo $i ?>">
                    <?php echo $i+1 ?>
                </a>
                <?php if( $i === $pagina ) { ?>
                    </li>
            <?php }} ?>
			
			<?php if($pagina < $pgTotal-1) {?>
			     <li class="waves-effect"><a href="?pg=<?php echo $pagina+1?>"><i class="material-icons">chevron_right</i></a></li>
            <?php }else{ ?>
                <li class="disabled"><a><i class="material-icons">chevron_right</i></a></li>
            <?php } ?>
    
 </ul>   
    
   <!--
            <?php if($cant == 0) { ?>
				<img src="/application/blocks/generargaleria/images/galeria-sin-fotos.jpg" width="100%" style="border-radius:5px;" />
			<?php }else{ ?>
            	<p style="font-size: 15px;text-align: center;width: 100%;float: left;">Página <b><?php echo $pagina+1 ?></b> de <b><?php echo $pgTotal ?></b></p><br />
            <?php } ?>
   -->         


<div class="detalle_item" id="capa_detalle" style="display: none; margin-bottom:20px">
    <a onclick="cerrar();" style="color:#000"><i class="material-icons cerrar_izquierda waves-effect waves-block" style="padding:10px">close</i></a>	
    
    <div class="card">
        <div class="card-image waves-effect waves-block waves-light">
          <img id="imagen" width="100%"/>
        </div>
        <div class="card-content">
          <span class="card-title grey-text text-darken-4" id="nombre"></span>
        </div>            

    </div>
    
</div>

<script>
	function cerrar(){
		$("#capa_detalle").hide();
        $("#paginacion").fadeIn();
        $("#galeria").fadeIn();
        $("#capa_item").show();
	}
   function addData(src,nomb){
        $("#capa_item").hide();
        $("#galeria").hide();
        $("#paginacion").hide();
		$("#capa_detalle").fadeIn("slow");
		$('#imagen').attr('src',src);
		$("#nombre").html(nomb);
    }
</script>




<div style="clear:left"></div>
<?php } else { ?>
        <div class="ccm-galeria-placeholder">
            <p><?php echo t('Sin imágenes para mostrar.'); ?></p>
        </div>
        <?php }} ?>
            
<?php } ?>
			
