<?php  defined('C5_EXECUTE') or die('Access denied.'); ?>
<?php  echo Loader::helper('concrete/dashboard')->getDashboardPaneFooterWrapper();