<?php   defined('C5_EXECUTE') or die("Access Denied."); ?>
<b><?php   echo t("Breadcrumbs delimiter:"); ?></b><br />
<input type="text" name="delimiter" size="10" value="<?php   echo h($delimiter); ?>"><br />